﻿namespace WebApplication1.Models
{
    public class Staff
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
